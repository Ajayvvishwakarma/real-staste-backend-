# Routes package - temporarily only auth until SQLite conversion is complete
# MongoDB-only: do not import or expose auth (SQLite)
# from . import users, properties, admin, appointments, contacts, dashboard

__all__ = []
# __all__ = ["auth", "users", "properties", "admin", "appointments", "contacts", "dashboard"]